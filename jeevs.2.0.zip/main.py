"""
main.py — Jeevs Entry Point
-----------------------------
Usage:
  python main.py
  python main.py --help
  python main.py --version
  python main.py --provider openai    # override LLM provider

Kept intentionally thin: argument parsing only.
All logic lives in shell.py, agent.py, tools.py, memory.py.
"""

import argparse
import os
import sys


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="jeevs",
        description="Jeevs — Intelligent AI-powered command-line shell",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Environment variables:\n"
            "  ANTHROPIC_API_KEY   API key for Anthropic Claude (default provider)\n"
            "  OPENAI_API_KEY      API key for OpenAI-compatible APIs\n"
            "  JEEVS_LLM_PROVIDER  'anthropic' or 'openai' (default: anthropic)\n"
            "  JEEVS_MODEL         Override the model name\n"
            "  OPENAI_BASE_URL     Override OpenAI base URL (for local models)\n"
        ),
    )
    parser.add_argument(
        "--version", action="version", version="Jeevs 0.1.0 (MVP)"
    )
    parser.add_argument(
        "--provider",
        choices=["anthropic", "openai"],
        default=None,
        help="LLM provider to use (overrides JEEVS_LLM_PROVIDER env var)",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="Model name to use (overrides JEEVS_MODEL env var)",
    )
    return parser.parse_args()


def main() -> None:
    args = _parse_args()

    # Apply CLI overrides before config is imported by other modules
    if args.provider:
        os.environ["JEEVS_LLM_PROVIDER"] = args.provider
    if args.model:
        os.environ["JEEVS_MODEL"] = args.model

    # Late import so env vars are set before config.py reads them
    from shell import JeevsShell

    try:
        JeevsShell().run()
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(0)


if __name__ == "__main__":
    main()
