"""
agent.py — Jeevs Agent (LLM Reasoning Layer)
----------------------------------------------
Responsibility: translate natural-language user input into a *structured plan*
— an ordered list of tool calls with arguments.

The agent does NOT execute tools. It only reasons and plans.
Execution happens in shell.py after user confirmation.

Architecture:
  - Build a system prompt that describes available tools.
  - Send conversation history + current user input to the LLM.
  - Parse the LLM's JSON response into a list of ToolCall objects.
  - Return the plan to shell.py.

Supports: Anthropic Claude (default) and any OpenAI-compatible API.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from config import (
    ANTHROPIC_API_KEY,
    ANTHROPIC_MODEL,
    LLM_PROVIDER,
    MAX_TOKENS,
    OPENAI_API_KEY,
    OPENAI_BASE_URL,
    OPENAI_MODEL,
    TEMPERATURE,
)
from memory import SessionMemory
from tools import TOOL_REGISTRY, ToolDefinition


# ── Data Structures ───────────────────────────────────────────────────────────

@dataclass
class ToolCall:
    """A single planned tool invocation."""
    tool_name: str
    args: dict[str, Any] = field(default_factory=dict)
    reason: str = ""          # LLM's justification (shown to user)


@dataclass
class AgentPlan:
    """The full plan returned by the agent for one user turn."""
    steps: list[ToolCall] = field(default_factory=list)
    explanation: str = ""     # Free-text explanation before the plan
    raw_response: str = ""    # Original LLM text (for debugging)

    @property
    def is_empty(self) -> bool:
        return len(self.steps) == 0


class AgentError(Exception):
    """Raised when the LLM cannot be reached or returns an unparseable response."""


# ── System Prompt ─────────────────────────────────────────────────────────────

def _build_system_prompt() -> str:
    tool_docs = []
    for t in TOOL_REGISTRY:
        params = {p.name: {"type": p.type, "description": p.description, "required": p.required}
                  for p in t.params}
        tool_docs.append(
            f"Tool: {t.name}\n"
            f"Description: {t.description}\n"
            f"Parameters: {json.dumps(params, indent=2)}"
        )

    tools_block = "\n\n".join(tool_docs)

    return f"""You are Jeevs, an intelligent command-line shell assistant.
Your role is to interpret the user's natural-language instruction and produce a
structured execution plan — a JSON list of tool calls.

AVAILABLE TOOLS
===============
{tools_block}

RESPONSE FORMAT
===============
Always respond with valid JSON only. No prose before or after.
Return an object with exactly these keys:

{{
  "explanation": "One sentence describing what you will do and why.",
  "steps": [
    {{
      "tool": "<tool_name>",
      "args": {{ "<param>": "<value>", ... }},
      "reason": "One-line justification for this step."
    }}
  ]
}}

RULES
=====
1. Use only the tools listed above. Do not invent tools.
2. If the user's request is ambiguous, pick the safest, most conservative interpretation.
3. If the request cannot be satisfied with the available tools, return an empty steps list
   and explain why in "explanation".
4. Prefer run_shell_command for complex queries (find, grep, du, ps, etc.).
5. Never chain destructive commands without clear user intent.
6. Use filesystem_list / filesystem_read before writing or deleting.
7. Keep shell commands simple, explicit, and portable (prefer POSIX).
"""


# ── LLM Callers ──────────────────────────────────────────────────────────────

def _call_anthropic(messages: list[dict], system: str) -> str:
    if not ANTHROPIC_API_KEY:
        raise AgentError(
            "ANTHROPIC_API_KEY is not set. "
            "Export it with: export ANTHROPIC_API_KEY=sk-ant-..."
        )
    payload = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "system": system,
        "messages": messages,
    }
    return _http_post(
        url="https://api.anthropic.com/v1/messages",
        payload=payload,
        headers={
            "x-api-key": ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        response_extractor=lambda d: d["content"][0]["text"],
    )


def _call_openai(messages: list[dict], system: str) -> str:
    if not OPENAI_API_KEY:
        raise AgentError(
            "OPENAI_API_KEY is not set. "
            "Export it with: export OPENAI_API_KEY=sk-..."
        )
    all_messages = [{"role": "system", "content": system}] + messages
    payload = {
        "model": OPENAI_MODEL,
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "messages": all_messages,
    }
    return _http_post(
        url=f"{OPENAI_BASE_URL}/chat/completions",
        payload=payload,
        headers={
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "content-type": "application/json",
        },
        response_extractor=lambda d: d["choices"][0]["message"]["content"],
    )


def _http_post(
    url: str,
    payload: dict,
    headers: dict,
    response_extractor,
) -> str:
    data = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(url, data=data, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            return response_extractor(body)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise AgentError(f"LLM API error {e.code}: {body[:400]}")
    except urllib.error.URLError as e:
        raise AgentError(f"Network error reaching LLM: {e.reason}")


# ── Response Parser ───────────────────────────────────────────────────────────

def _parse_plan(raw: str) -> AgentPlan:
    """Extract JSON from LLM response and convert to AgentPlan."""
    # Strip markdown code fences if present
    text = re.sub(r"```(?:json)?", "", raw).strip()

    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        # Attempt to find the JSON object within surrounding text
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
            except json.JSONDecodeError:
                raise AgentError(f"Could not parse LLM response as JSON.\n\nRaw response:\n{raw[:600]}")
        else:
            raise AgentError(f"LLM response contained no JSON.\n\nRaw response:\n{raw[:600]}")

    steps: list[ToolCall] = []
    for step in data.get("steps", []):
        steps.append(ToolCall(
            tool_name=step.get("tool", ""),
            args=step.get("args", {}),
            reason=step.get("reason", ""),
        ))

    return AgentPlan(
        steps=steps,
        explanation=data.get("explanation", ""),
        raw_response=raw,
    )


# ── Public Interface ──────────────────────────────────────────────────────────

class Agent:
    """
    Stateless reasoning engine.
    Accepts conversation history + user input → returns AgentPlan.
    """

    def __init__(self) -> None:
        self._system = _build_system_prompt()

    def plan(self, user_input: str, memory: SessionMemory) -> AgentPlan:
        """Ask the LLM to produce a plan for `user_input`."""
        messages = memory.get_history()
        # Add the current user message (not yet in memory)
        messages = messages + [{"role": "user", "content": user_input}]

        if LLM_PROVIDER == "anthropic":
            raw = _call_anthropic(messages, self._system)
        elif LLM_PROVIDER == "openai":
            raw = _call_openai(messages, self._system)
        else:
            raise AgentError(f"Unknown LLM provider: {LLM_PROVIDER!r}")

        return _parse_plan(raw)
