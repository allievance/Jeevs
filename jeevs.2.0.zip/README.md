# Jeevs — Intelligent AI-Powered Shell

> *"Jeevs is not a chatbot in a shell. It is an intelligent, modular shell."*

Jeevs interprets natural-language instructions, plans a sequence of tool calls,
shows you the plan for confirmation, and then executes it — with full logging.

---

## Quick Start

```bash
# 1. Clone / copy the project
cd jeevs/

# 2. Set your API key (Anthropic by default)
export ANTHROPIC_API_KEY=sk-ant-...

# 3. Run
python main.py
```

You should see:

```
╔══════════════════════════════════════╗
║  Jeevs — Intelligent Shell  v0.1.0  ║
╚══════════════════════════════════════╝

Jeevs > _
```

---

## Example Session

```
Jeevs > list the largest files in this directory

  Thinking…

Jeevs plan:
  1. Run shell command: du -ah . | sort -rh | head -20
     List files by size, largest first.

Execute? (y/n) y
  [1/1] run_shell_command…
────────────────────────────────────────────────────
1.2M    ./data/corpus.json
340K    ./models/weights.pt
 88K    ./logs/run_20240601.log
...
────────────────────────────────────────────────────

Jeevs > read the README
  Thinking…

Jeevs plan:
  1. Read file: README.md

  [1/1] filesystem_read…   ← no confirmation needed (read-only)
────────────────────────────────────────────────────
── README.md  (120 lines, 3 KB) ──
...
```

---

## Architecture

```
User Input
    │
    ▼
shell.py  ◄──── Built-in commands (:help, :tools, :exit …)
    │
    ├─► agent.py ──► LLM API (Anthropic / OpenAI)
    │       │
    │       └─► Returns AgentPlan (list of ToolCall objects)
    │
    ├─► Renders plan, prompts for confirmation
    │
    ├─► tools.py  ──► Executes confirmed tool calls
    │       │
    │       └─► filesystem_list / read / write
    │           run_shell_command
    │           git_commit
    │
    ├─► memory.py ──► Updates session history (in-memory)
    │
    └─► memory.py ──► Appends to ~/.jeevs/logs.txt (JSONL)
```

### Module Responsibilities

| File | Responsibility |
|------|----------------|
| `main.py` | Argument parsing, entry point |
| `config.py` | API keys, model names, display constants |
| `agent.py` | LLM calls, JSON plan parsing |
| `tools.py` | Tool registry + implementations |
| `shell.py` | REPL loop, plan display, confirmation, execution |
| `memory.py` | Session history (RAM) + action log (disk) |

---

## Configuration

All settings are controlled by environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `ANTHROPIC_API_KEY` | — | **Required** for Anthropic provider |
| `OPENAI_API_KEY` | — | Required for OpenAI provider |
| `JEEVS_LLM_PROVIDER` | `anthropic` | `anthropic` or `openai` |
| `JEEVS_MODEL` | `claude-sonnet-4-20250514` | Model name override |
| `OPENAI_BASE_URL` | `https://api.openai.com/v1` | For local/custom endpoints |

### Using OpenAI

```bash
export JEEVS_LLM_PROVIDER=openai
export OPENAI_API_KEY=sk-...
python main.py
```

### Using a local model (Ollama)

```bash
export JEEVS_LLM_PROVIDER=openai
export OPENAI_API_KEY=ollama        # any non-empty value
export OPENAI_BASE_URL=http://localhost:11434/v1
export JEEVS_MODEL=llama3.2
python main.py
```

---

## Built-in Commands

| Command | Description |
|---------|-------------|
| `:help` | Show help |
| `:tools` | List available tools |
| `:history` | Show session message count |
| `:clear` | Clear the terminal |
| `:exit` | Quit Jeevs |

---

## Available Tools

| Tool | Mutates? | Description |
|------|----------|-------------|
| `filesystem_list(path)` | No | List directory contents |
| `filesystem_read(path)` | No | Read a text file |
| `filesystem_write(path, content)` | **Yes** | Write/create a file |
| `run_shell_command(command)` | **Yes** | Run a shell command |
| `git_commit(message)` | **Yes** | Stage all changes + commit |

Read-only tools execute immediately. Mutating tools require `y` confirmation.

---

## Logs

All actions are logged to `~/.jeevs/logs.txt` in JSONL format:

```jsonl
{"event": "session_start", "ts": "2025-01-01T12:00:00Z"}
{"event": "user_input", "input": "list largest files", "ts": "..."}
{"event": "plan", "steps": [...], "ts": "..."}
{"event": "execution", "tool": "run_shell_command", "confirmed": true, "result": "...", "ts": "..."}
```

Query with `jq`:

```bash
jq 'select(.event == "execution")' ~/.jeevs/logs.txt
jq 'select(.event == "error")' ~/.jeevs/logs.txt
```

---

## Adding a New Tool

1. Write the function in `tools.py` (return `str`, raise `ToolError` on failure):

```python
def _my_tool(param: str) -> str:
    ...
    return "result string"
```

2. Register it in `TOOL_REGISTRY`:

```python
ToolDefinition(
    name="my_tool",
    description="Does X when given Y.",
    params=[ToolParam("param", "string", "Description of param")],
    fn=_my_tool,
    plan_template="My tool: {param}",
    mutates=True,   # True = requires confirmation
),
```

That's it. The agent and shell pick it up automatically.

---

## Safety Model

- **Plan-first**: the agent never executes without first showing a plan.
- **Confirmation gate**: all mutating operations require explicit `y`.
- **Dangerous pattern warnings**: commands matching patterns like `rm -rf`,
  `sudo`, `curl | bash` are flagged with a ⚠ DANGEROUS label.
- **No autonomy loops**: Jeevs does not re-invoke itself or chain plans
  without returning to the user between each turn.
- **Timeout**: shell commands time out after 30 seconds by default.

---

## Recommended Next Steps

1. **Tool expansion** — `web_search`, `http_request`, `python_eval`, `docker_run`
2. **Streaming output** — stream LLM tokens instead of waiting for full response
3. **Plan editing** — let users edit the plan JSON before confirming
4. **Undo / rollback** — snapshot files before write; offer rollback
5. **Plugin system** — auto-discover `jeevs_plugin_*.py` tool files
6. **TUI** — replace readline REPL with a `textual`-based interface
7. **Multi-step autonomy mode** — opt-in flag to auto-confirm non-destructive steps
8. **Test suite** — pytest fixtures with mocked LLM + tool calls
