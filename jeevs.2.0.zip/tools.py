"""
tools.py — Jeevs Tool Registry
--------------------------------
Each tool is a plain Python function wrapped in a ToolDefinition dataclass.

Adding a new tool:
  1. Write the function (returns a string result or raises ToolError).
  2. Create a ToolDefinition and append it to TOOL_REGISTRY.
  3. The agent and shell layers pick it up automatically — no other changes needed.

Design principles:
  - Every tool returns a *string* (success text or error message).
  - Tools never print; they return. The shell layer handles display.
  - Side-effects only happen after user confirmation (enforced in shell.py).
"""

from __future__ import annotations

import os
import subprocess
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable


# ── Exceptions ────────────────────────────────────────────────────────────────

class ToolError(Exception):
    """Raised when a tool cannot complete its task safely."""


# ── Tool Definition ───────────────────────────────────────────────────────────

@dataclass
class ToolParam:
    name: str
    type: str          # "string" | "integer" | "boolean"
    description: str
    required: bool = True


@dataclass
class ToolDefinition:
    name: str
    description: str
    params: list[ToolParam]
    fn: Callable[..., str]
    # Human-readable summary for plan display (uses {param} interpolation)
    plan_template: str = ""
    # Whether this tool mutates state (triggers confirmation prompt)
    mutates: bool = True

    def summary(self, args: dict[str, Any]) -> str:
        """Render the plan_template with provided args."""
        if self.plan_template:
            try:
                return self.plan_template.format(**args)
            except KeyError:
                pass
        parts = [f"{k}={v!r}" for k, v in args.items()]
        return f"{self.name}({', '.join(parts)})"


# ── Tool Implementations ──────────────────────────────────────────────────────

def _filesystem_list(path: str = ".") -> str:
    target = Path(path).expanduser().resolve()
    if not target.exists():
        raise ToolError(f"Path does not exist: {target}")
    if not target.is_dir():
        raise ToolError(f"Not a directory: {target}")

    entries = sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower()))
    lines: list[str] = []
    for entry in entries:
        if entry.is_dir():
            lines.append(f"  📁  {entry.name}/")
        else:
            size = entry.stat().st_size
            lines.append(f"  📄  {entry.name:<40} {_human_size(size):>8}")
    header = f"Contents of {target}  ({len(entries)} items)\n" + "─" * 52
    return header + "\n" + "\n".join(lines) if lines else header + "\n  (empty)"


def _filesystem_read(path: str) -> str:
    target = Path(path).expanduser().resolve()
    if not target.exists():
        raise ToolError(f"File does not exist: {target}")
    if not target.is_file():
        raise ToolError(f"Not a regular file: {target}")
    size = target.stat().st_size
    if size > 512_000:
        raise ToolError(f"File too large to display ({_human_size(size)}). Use a pager.")
    try:
        content = target.read_text(encoding="utf-8", errors="replace")
    except PermissionError:
        raise ToolError(f"Permission denied: {target}")
    lines = content.splitlines()
    header = f"── {target}  ({len(lines)} lines, {_human_size(size)}) ──\n"
    return header + content


def _filesystem_write(path: str, content: str) -> str:
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    existed = target.exists()
    try:
        target.write_text(content, encoding="utf-8")
    except PermissionError:
        raise ToolError(f"Permission denied: {target}")
    verb = "Updated" if existed else "Created"
    return f"{verb} {target}  ({len(content.encode())} bytes written)"


def _run_shell_command(command: str, timeout: int = 30) -> str:
    """Run an arbitrary shell command and capture stdout + stderr."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = result.stdout
        if result.stderr:
            output += ("\n" if output else "") + f"[stderr]\n{result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        raise ToolError(f"Command timed out after {timeout}s: {command}")


def _git_commit(message: str) -> str:
    """Stage all changes and create a git commit."""
    stage = subprocess.run(
        "git add -A",
        shell=True, capture_output=True, text=True,
    )
    if stage.returncode != 0:
        raise ToolError(f"git add failed:\n{stage.stderr.strip()}")

    commit = subprocess.run(
        ["git", "commit", "-m", message],
        capture_output=True, text=True,
    )
    if commit.returncode != 0:
        raise ToolError(f"git commit failed:\n{commit.stderr.strip()}")
    return commit.stdout.strip()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


# ── Registry ──────────────────────────────────────────────────────────────────

TOOL_REGISTRY: list[ToolDefinition] = [
    ToolDefinition(
        name="filesystem_list",
        description="List the contents of a directory, showing file names and sizes.",
        params=[
            ToolParam("path", "string", "Directory path to list (default: current directory)", required=False),
        ],
        fn=_filesystem_list,
        plan_template="List directory: {path}",
        mutates=False,
    ),
    ToolDefinition(
        name="filesystem_read",
        description="Read and display the contents of a text file.",
        params=[
            ToolParam("path", "string", "Path to the file to read"),
        ],
        fn=_filesystem_read,
        plan_template="Read file: {path}",
        mutates=False,
    ),
    ToolDefinition(
        name="filesystem_write",
        description="Write (create or overwrite) a file with the given content.",
        params=[
            ToolParam("path", "string", "Destination file path"),
            ToolParam("content", "string", "Text content to write"),
        ],
        fn=_filesystem_write,
        plan_template="Write file: {path}",
        mutates=True,
    ),
    ToolDefinition(
        name="run_shell_command",
        description=(
            "Execute a shell command and return its output. "
            "Use for file operations, searching, system info, build tasks, etc."
        ),
        params=[
            ToolParam("command", "string", "The shell command to run"),
            ToolParam("timeout", "integer", "Timeout in seconds (default: 30)", required=False),
        ],
        fn=_run_shell_command,
        plan_template="Run shell command: {command}",
        mutates=True,
    ),
    ToolDefinition(
        name="git_commit",
        description="Stage all current changes (git add -A) and create a commit with the given message.",
        params=[
            ToolParam("message", "string", "Commit message"),
        ],
        fn=_git_commit,
        plan_template='Git commit: "{message}"',
        mutates=True,
    ),
]

# Fast lookup by name
TOOLS_BY_NAME: dict[str, ToolDefinition] = {t.name: t for t in TOOL_REGISTRY}


def get_tool(name: str) -> ToolDefinition | None:
    return TOOLS_BY_NAME.get(name)


def list_tools() -> str:
    lines = ["Available tools:\n"]
    for t in TOOL_REGISTRY:
        params = ", ".join(
            f"{p.name}: {p.type}" + ("" if p.required else " (optional)")
            for p in t.params
        )
        lines.append(f"  • {t.name}({params})\n    {t.description}\n")
    return "\n".join(lines)
