"""
memory.py — Jeevs Session Memory & Logging
-------------------------------------------
Two responsibilities:
  1. In-memory conversation history for multi-turn LLM context.
  2. Persistent, append-only action log at ~/.jeevs/logs.txt.

Design note: Memory and logging are deliberately separate concerns.
  - Memory is ephemeral and resets each session.
  - Logs are permanent audit records.
"""

from __future__ import annotations

import json
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from config import LOG_FILE, MAX_HISTORY_TURNS


# ── Session Memory ────────────────────────────────────────────────────────────

class SessionMemory:
    """
    Stores the conversation as a list of {"role": ..., "content": ...} dicts,
    compatible with both Anthropic and OpenAI message formats.
    """

    def __init__(self) -> None:
        self._history: list[dict[str, str]] = []

    def add_user(self, text: str) -> None:
        self._history.append({"role": "user", "content": text})

    def add_assistant(self, text: str) -> None:
        self._history.append({"role": "assistant", "content": text})

    def get_history(self) -> list[dict[str, str]]:
        """Return the most recent MAX_HISTORY_TURNS turns (pairs)."""
        # Each turn = 1 message; we keep the last N messages total.
        return self._history[-(MAX_HISTORY_TURNS * 2):]

    def clear(self) -> None:
        self._history.clear()

    def __len__(self) -> int:
        return len(self._history)


# ── Persistent Logger ─────────────────────────────────────────────────────────

class ActionLogger:
    """
    Appends structured JSONL entries to ~/.jeevs/logs.txt.
    Each entry is one JSON object per line for easy grep / jq querying.
    """

    def __init__(self, log_path: Path = LOG_FILE) -> None:
        self.log_path = log_path
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def _write(self, record: dict[str, Any]) -> None:
        record["ts"] = datetime.now(tz=timezone.utc).isoformat()
        with self.log_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")

    def log_input(self, user_input: str) -> None:
        self._write({"event": "user_input", "input": user_input})

    def log_plan(self, steps: list[dict[str, Any]]) -> None:
        self._write({"event": "plan", "steps": steps})

    def log_execution(
        self,
        tool: str,
        args: dict[str, Any],
        result: str,
        confirmed: bool,
    ) -> None:
        self._write({
            "event": "execution",
            "tool": tool,
            "args": args,
            "confirmed": confirmed,
            "result": textwrap.shorten(result, width=500),
        })

    def log_error(self, message: str) -> None:
        self._write({"event": "error", "message": message})

    def log_session_start(self) -> None:
        self._write({"event": "session_start"})

    def log_session_end(self) -> None:
        self._write({"event": "session_end"})
