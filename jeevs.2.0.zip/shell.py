"""
shell.py — Jeevs Shell (Display & Confirmation Layer)
------------------------------------------------------
Responsibility: everything the user *sees and interacts with*.

  - Render the plan before execution.
  - Prompt for confirmation on mutating tools.
  - Execute confirmed tool calls.
  - Display results with formatting.
  - Handle built-in commands (:help, :history, :tools, :clear, :exit).

This layer imports from agent.py and tools.py but never reasons about intent.
It is purely presentation + gating.
"""

from __future__ import annotations

import os
import sys
import textwrap
from typing import Any

from agent import Agent, AgentError, AgentPlan, ToolCall
from config import (
    DANGEROUS_PATTERNS,
    DIM_COLOR,
    ERROR_COLOR,
    PLAN_HEADER,
    PROMPT,
    RESET_COLOR,
    SUCCESS_COLOR,
    WARN_COLOR,
)
from memory import ActionLogger, SessionMemory
from tools import TOOL_REGISTRY, ToolError, get_tool, list_tools


# ── Formatting helpers ────────────────────────────────────────────────────────

def _c(color: str, text: str) -> str:
    """Wrap text in ANSI color if stdout is a TTY."""
    if sys.stdout.isatty():
        return f"{color}{text}{RESET_COLOR}"
    return text


def _banner() -> str:
    return f"""
{_c(SUCCESS_COLOR, '╔══════════════════════════════════════╗')}
{_c(SUCCESS_COLOR, '║')}  {_c(WARN_COLOR, 'Jeevs')} — Intelligent Shell  v0.1.0  {_c(SUCCESS_COLOR, '║')}
{_c(SUCCESS_COLOR, '╚══════════════════════════════════════╝')}
Type a natural-language instruction, or {_c(WARN_COLOR, ':help')} for built-in commands.
"""


def _separator(char: str = "─", width: int = 52) -> str:
    return _c(DIM_COLOR, char * width)


# ── Plan renderer ─────────────────────────────────────────────────────────────

def _is_dangerous(command: str) -> bool:
    import re
    lower = command.lower()
    if any(pat in lower for pat in DANGEROUS_PATTERNS):
        return True
    from config import DANGEROUS_REGEX_PATTERNS
    return any(re.search(pat, lower) for pat in DANGEROUS_REGEX_PATTERNS)


def _render_plan(plan: AgentPlan) -> None:
    print(PLAN_HEADER)
    if plan.explanation:
        print(f"  {_c(DIM_COLOR, plan.explanation)}")
    print()

    for i, step in enumerate(plan.steps, 1):
        tool_def = get_tool(step.tool_name)
        label = tool_def.summary(step.args) if tool_def else f"{step.tool_name}({step.args})"

        # Flag dangerous commands visually
        cmd = step.args.get("command", "") or step.args.get("content", "")
        if _is_dangerous(cmd):
            danger_tag = _c(ERROR_COLOR, " ⚠ DANGEROUS")
        else:
            danger_tag = ""

        print(f"  {_c(WARN_COLOR, str(i) + '.')} {label}{danger_tag}")
        if step.reason:
            print(f"     {_c(DIM_COLOR, step.reason)}")

    print()


# ── Execution ─────────────────────────────────────────────────────────────────

def _execute_step(step: ToolCall) -> str:
    """Call the registered tool function and return its output string."""
    tool_def = get_tool(step.tool_name)
    if tool_def is None:
        raise ToolError(f"Unknown tool: {step.tool_name!r}")

    # Map args dict → function keyword arguments
    # Drop None values for optional params
    kwargs = {k: v for k, v in step.args.items() if v is not None}
    return tool_def.fn(**kwargs)


def _confirm(prompt_text: str) -> bool:
    """Ask y/n question; return True if user confirms."""
    try:
        answer = input(prompt_text).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False
    return answer in ("y", "yes")


# ── Built-in commands ─────────────────────────────────────────────────────────

BUILTINS = {
    ":help",
    ":h",
    ":tools",
    ":history",
    ":clear",
    ":exit",
    ":quit",
    ":q",
}


def _handle_builtin(cmd: str, memory: SessionMemory, logger: ActionLogger) -> bool:
    """Handle a built-in command. Returns True if handled."""
    cmd = cmd.strip().lower()
    if cmd not in BUILTINS:
        return False

    if cmd in (":exit", ":quit", ":q"):
        print(_c(DIM_COLOR, "\nGoodbye.\n"))
        logger.log_session_end()
        sys.exit(0)

    elif cmd in (":help", ":h"):
        print(f"""
{_c(WARN_COLOR, 'Built-in commands:')}
  :help    — Show this message
  :tools   — List available tools
  :history — Show session history length
  :clear   — Clear the screen
  :exit    — Exit Jeevs

{_c(WARN_COLOR, 'Tips:')}
  • Type natural language: "list the largest files here"
  • Use quotes for literal shell: "run: echo hello"
  • Jeevs always shows a plan before executing.
""")

    elif cmd == ":tools":
        print()
        print(list_tools())

    elif cmd == ":history":
        n = len(memory)
        print(f"\n  Session history: {n} message(s) in context.\n")

    elif cmd == ":clear":
        os.system("clear" if sys.platform != "win32" else "cls")

    return True


# ── Main Shell Loop ───────────────────────────────────────────────────────────

class JeevsShell:
    """
    The REPL loop. Ties together Agent, Tools, Memory, and Logger.
    """

    def __init__(self) -> None:
        self.agent  = Agent()
        self.memory = SessionMemory()
        self.logger = ActionLogger()

    def run(self) -> None:
        self.logger.log_session_start()
        print(_banner())

        while True:
            try:
                user_input = input(PROMPT).strip()
            except (KeyboardInterrupt, EOFError):
                print()
                if _confirm("  Exit Jeevs? (y/n) "):
                    self.logger.log_session_end()
                    print(_c(DIM_COLOR, "\nGoodbye.\n"))
                    break
                continue

            if not user_input:
                continue

            # ── Built-in commands ──────────────────────────────────────────
            if user_input.startswith(":"):
                _handle_builtin(user_input, self.memory, self.logger)
                continue

            # ── Log the raw input ──────────────────────────────────────────
            self.logger.log_input(user_input)

            # ── Agent: plan ────────────────────────────────────────────────
            print(_c(DIM_COLOR, "  Thinking…"))
            try:
                plan = self.agent.plan(user_input, self.memory)
            except AgentError as e:
                print(_c(ERROR_COLOR, f"\n  Agent error: {e}\n"))
                self.logger.log_error(str(e))
                continue

            # ── No steps — agent couldn't help ────────────────────────────
            if plan.is_empty:
                print(f"\n  {plan.explanation or 'No plan could be generated for that request.'}\n")
                self.memory.add_user(user_input)
                self.memory.add_assistant(plan.explanation)
                continue

            # ── Render the plan ────────────────────────────────────────────
            _render_plan(plan)
            self.logger.log_plan([
                {"tool": s.tool_name, "args": s.args} for s in plan.steps
            ])

            # ── Determine if confirmation is needed ────────────────────────
            needs_confirm = any(
                get_tool(s.tool_name) and get_tool(s.tool_name).mutates
                for s in plan.steps
            )

            if needs_confirm:
                if not _confirm("Execute? (y/n) "):
                    print(_c(DIM_COLOR, "  Cancelled.\n"))
                    self.logger.log_execution("(cancelled)", {}, "", confirmed=False)
                    self.memory.add_user(user_input)
                    self.memory.add_assistant("(user cancelled the plan)")
                    continue

            # ── Execute each step ──────────────────────────────────────────
            all_results: list[str] = []

            for i, step in enumerate(plan.steps, 1):
                print(_c(DIM_COLOR, f"  [{i}/{len(plan.steps)}] {step.tool_name}…"))
                try:
                    result = _execute_step(step)
                    all_results.append(result)

                    # Display result
                    print(_separator())
                    print(result)
                    print(_separator())

                    self.logger.log_execution(
                        step.tool_name, step.args, result, confirmed=True
                    )

                except ToolError as e:
                    err_msg = str(e)
                    print(_c(ERROR_COLOR, f"\n  Tool error: {err_msg}\n"))
                    self.logger.log_error(err_msg)
                    all_results.append(f"ERROR: {err_msg}")
                    # Ask whether to continue remaining steps
                    if i < len(plan.steps):
                        if not _confirm("  Continue with remaining steps? (y/n) "):
                            break

            # ── Update memory with what happened ───────────────────────────
            combined_result = "\n---\n".join(all_results)
            assistant_summary = (
                f"Executed plan: {plan.explanation}\n"
                f"Results:\n{textwrap.shorten(combined_result, width=1000)}"
            )
            self.memory.add_user(user_input)
            self.memory.add_assistant(assistant_summary)
            print()
