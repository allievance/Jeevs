"""
config.py — Jeevs Configuration
Centralizes API keys, model selection, and runtime settings.
All user-configurable values live here.
"""

import os
from pathlib import Path

# ── Directories ───────────────────────────────────────────────────────────────
JEEVS_DIR = Path.home() / ".jeevs"
LOG_FILE   = JEEVS_DIR / "logs.txt"
JEEVS_DIR.mkdir(parents=True, exist_ok=True)

# ── LLM Provider ──────────────────────────────────────────────────────────────
# Supported: "anthropic" | "openai"
LLM_PROVIDER = os.environ.get("JEEVS_LLM_PROVIDER", "anthropic")

# Anthropic settings
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL   = os.environ.get("JEEVS_MODEL", "claude-sonnet-4-20250514")

# OpenAI-compatible settings (also works with local Ollama, etc.)
OPENAI_API_KEY  = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL    = os.environ.get("JEEVS_MODEL", "gpt-4o")
OPENAI_BASE_URL = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")

# ── Agent behaviour ───────────────────────────────────────────────────────────
MAX_HISTORY_TURNS = 20          # How many prior turns to include as context
MAX_TOKENS        = 1024        # Max tokens for LLM responses
TEMPERATURE       = 0.2         # Low temperature → deterministic tool calls

# ── Safety ────────────────────────────────────────────────────────────────────
# Commands whose substrings trigger an extra "DANGEROUS" warning
DANGEROUS_PATTERNS = [
    "rm -rf", "mkfs", "dd if=",
    ":(){:|:&};:", "chmod 777", "sudo",
    # Pipe-to-shell patterns matched via regex in shell.py
]

# Regex patterns checked separately (more powerful matching)
DANGEROUS_REGEX_PATTERNS = [
    r"curl\b.*\|\s*(ba)?sh",    # curl ... | bash / sh
    r"wget\b.*\|\s*(ba)?sh",    # wget ... | bash / sh
    r"rm\s+-[rf]{1,3}\s+/",     # rm -rf /something
]

# ── Display ───────────────────────────────────────────────────────────────────
PROMPT        = "Jeevs > "
PLAN_HEADER   = "\n\033[1;36mJeevs plan:\033[0m"
WARN_COLOR    = "\033[1;33m"
ERROR_COLOR   = "\033[1;31m"
SUCCESS_COLOR = "\033[1;32m"
DIM_COLOR     = "\033[2m"
RESET_COLOR   = "\033[0m"
