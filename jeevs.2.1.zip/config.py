"""
config.py — Jeevs Configuration
All user-configurable values. Override via environment variables.
"""

import os
from pathlib import Path

# ── Directories ───────────────────────────────────────────────────────────────
JEEVS_DIR = Path.home() / ".jeevs"
LOG_FILE   = JEEVS_DIR / "logs.txt"
JEEVS_DIR.mkdir(parents=True, exist_ok=True)

# ── LLM Provider ──────────────────────────────────────────────────────────────
LLM_PROVIDER      = os.environ.get("JEEVS_LLM_PROVIDER", "anthropic")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL   = os.environ.get("JEEVS_MODEL", "claude-sonnet-4-20250514")
OPENAI_API_KEY    = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL      = os.environ.get("JEEVS_MODEL", "gpt-4o")
OPENAI_BASE_URL   = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")

# ── Agent behaviour ───────────────────────────────────────────────────────────
MAX_HISTORY_TURNS = int(os.environ.get("JEEVS_MAX_HISTORY", "20"))
MAX_TOKENS        = int(os.environ.get("JEEVS_MAX_TOKENS", "1024"))
TEMPERATURE       = float(os.environ.get("JEEVS_TEMPERATURE", "0.2"))

# ── Token budget (cost protection) ────────────────────────────────────────────
# Warn when estimated session usage reaches this many tokens.
TOKEN_BUDGET_WARN = int(os.environ.get("JEEVS_TOKEN_WARN", "40000"))
# Hard stop (raises TokenBudgetExceeded) at this limit.
TOKEN_BUDGET_HARD = int(os.environ.get("JEEVS_TOKEN_HARD", "100000"))

# ── Sandbox ───────────────────────────────────────────────────────────────────
# When set, all file and shell path operations must stay within this directory.
# Example: export JEEVS_SANDBOX_ROOT=~/projects/myapp
# Leave empty to disable sandboxing (default).
SANDBOX_ROOT = os.environ.get("JEEVS_SANDBOX_ROOT", "")

# ── Display ───────────────────────────────────────────────────────────────────
# Original bash versions used "jeevs>" (no space). The space is intentional
# in this Python version for readability, but the name is unchanged.
PROMPT        = "jeevs> "
PLAN_HEADER   = "\n\033[1;36mJeevs plan:\033[0m"
WARN_COLOR    = "\033[1;33m"
ERROR_COLOR   = "\033[1;31m"
SUCCESS_COLOR = "\033[1;32m"
DIM_COLOR     = "\033[2m"
RESET_COLOR   = "\033[0m"
DANGER_COLOR  = "\033[1;31m"
