# Jeevs — Intelligent AI-Powered Shell

> *"Jeevs is not a chatbot in a shell. It is an intelligent, modular shell."*

Jeevs interprets natural-language instructions, plans a sequence of tool calls,
shows you the plan for confirmation, and then executes it — with full logging.

---

## Quick Start

```bash
# 1. Clone / copy the project
cd jeevs/

# 2. Set your API key (Anthropic by default)
export ANTHROPIC_API_KEY=sk-ant-...

# 3. Run
python main.py
```

You should see:

```
╔══════════════════════════════════════╗
║  Jeevs — Intelligent Shell  v0.1.0  ║
╚══════════════════════════════════════╝

Jeevs > _
```

---

## Example Session

```
Jeevs > list the largest files in this directory

  Thinking…

Jeevs plan:
  1. Run shell command: du -ah . | sort -rh | head -20
     List files by size, largest first.

Execute? (y/n) y
  [1/1] run_shell_command…
────────────────────────────────────────────────────
1.2M    ./data/corpus.json
340K    ./models/weights.pt
 88K    ./logs/run_20240601.log
...
────────────────────────────────────────────────────

Jeevs > read the README
  Thinking…

Jeevs plan:
  1. Read file: README.md

  [1/1] filesystem_read…   ← no confirmation needed (read-only)
────────────────────────────────────────────────────
── README.md  (120 lines, 3 KB) ──
...
```

---

## Architecture

```
User Input
    │
    ▼
shell.py  ◄──── Built-in commands (:help, :tools, :exit …)
    │
    ├─► agent.py ──► LLM API (Anthropic / OpenAI)
    │       │
    │       └─► Returns AgentPlan (list of ToolCall objects)
    │
    ├─► Renders plan, prompts for confirmation
    │
    ├─► tools.py  ──► Executes confirmed tool calls
    │       │
    │       └─► filesystem_list / read / write
    │           run_shell_command
    │           git_commit
    │
    ├─► memory.py ──► Updates session history (in-memory)
    │
    └─► memory.py ──► Appends to ~/.jeevs/logs.txt (JSONL)
```

### Module Responsibilities

| File | Responsibility |
|------|----------------|
| `main.py` | Argument parsing, entry point |
| `config.py` | API keys, model names, display constants |
| `agent.py` | LLM calls, JSON plan parsing |
| `tools.py` | Tool registry + implementations |
| `shell.py` | REPL loop, plan display, confirmation, execution |
| `memory.py` | Session history (RAM) + action log (disk) |

---

## Configuration

All settings are controlled by environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `ANTHROPIC_API_KEY` | — | **Required** for Anthropic provider |
| `OPENAI_API_KEY` | — | Required for OpenAI provider |
| `JEEVS_LLM_PROVIDER` | `anthropic` | `anthropic` or `openai` |
| `JEEVS_MODEL` | `claude-sonnet-4-20250514` | Model name override |
| `OPENAI_BASE_URL` | `https://api.openai.com/v1` | For local/custom endpoints |

### Using OpenAI

```bash
export JEEVS_LLM_PROVIDER=openai
export OPENAI_API_KEY=sk-...
python main.py
```

### Using a local model (Ollama)

```bash
export JEEVS_LLM_PROVIDER=openai
export OPENAI_API_KEY=ollama        # any non-empty value
export OPENAI_BASE_URL=http://localhost:11434/v1
export JEEVS_MODEL=llama3.2
python main.py
```

---

## Built-in Commands

| Command | Description |
|---------|-------------|
| `:help` | Show help |
| `:tools` | List available tools |
| `:history` | Show session message count |
| `:clear` | Clear the terminal |
| `:exit` | Quit Jeevs |

---

## Available Tools

| Tool | Mutates? | Description |
|------|----------|-------------|
| `filesystem_list(path)` | No | List directory contents |
| `filesystem_read(path)` | No | Read a text file |
| `filesystem_write(path, content)` | **Yes** | Write/create a file |
| `run_shell_command(command)` | **Yes** | Run a shell command |
| `git_commit(message)` | **Yes** | Stage all changes + commit |

Read-only tools execute immediately. Mutating tools require `y` confirmation.

---

## Logs

All actions are logged to `~/.jeevs/logs.txt` in JSONL format:

```jsonl
{"event": "session_start", "ts": "2025-01-01T12:00:00Z"}
{"event": "user_input", "input": "list largest files", "ts": "..."}
{"event": "plan", "steps": [...], "ts": "..."}
{"event": "execution", "tool": "run_shell_command", "confirmed": true, "result": "...", "ts": "..."}
```

Query with `jq`:

```bash
jq 'select(.event == "execution")' ~/.jeevs/logs.txt
jq 'select(.event == "error")' ~/.jeevs/logs.txt
```

---

## Adding a New Tool

1. Write the function in `tools.py` (return `str`, raise `ToolError` on failure):

```python
def _my_tool(param: str) -> str:
    ...
    return "result string"
```

2. Register it in `TOOL_REGISTRY`:

```python
ToolDefinition(
    name="my_tool",
    description="Does X when given Y.",
    params=[ToolParam("param", "string", "Description of param")],
    fn=_my_tool,
    plan_template="My tool: {param}",
    mutates=True,   # True = requires confirmation
),
```

That's it. The agent and shell pick it up automatically.

---

## Safety Model

- **Plan-first**: the agent never executes without first showing a plan.
- **Confirmation gate**: all mutating operations require explicit `y`.
- **Dangerous pattern warnings**: commands matching patterns like `rm -rf`,
  `sudo`, `curl | bash` are flagged with a ⚠ DANGEROUS label.
- **No autonomy loops**: Jeevs does not re-invoke itself or chain plans
  without returning to the user between each turn.
- **Timeout**: shell commands time out after 30 seconds by default.

---

## Recommended Next Steps

1. **Tool expansion** — `web_search`, `http_request`, `python_eval`, `docker_run`
2. **Streaming output** — stream LLM tokens instead of waiting for full response
3. **Plan editing** — let users edit the plan JSON before confirming (✅ done in v0.2)
4. **Undo / rollback** — snapshot files before write; offer rollback
5. **Plugin system** — auto-discover `jeevs_plugin_*.py` tool files
6. **TUI** — replace readline REPL with a `textual`-based interface
7. **Multi-step autonomy mode** — opt-in flag to auto-confirm non-destructive steps
8. **Test suite** — pytest fixtures with mocked LLM + tool calls

---

## Origin & Provenance

Jeevs began as a bash script written across five sessions between December 2025
and January 2026. The session logs are preserved below as the project's founding
record.

### "At your service."

This greeting was introduced in **Session 2 (2025-12-24)** — Basha's idea — to
give the agent an active voice and distinguish it from a passive tool. It
appeared as the first line of output in every version of the bash prototype
(`jeevs_1.0` through `jeevs_1.3.2`) and is carried forward unchanged into this
Python implementation. It prints immediately after the version header each time
Jeevs starts.

### Session Logs

```
[01 · 2025-12-23 · Session 1]
Goal: Convert Jeevs from script to login shell.
Work: Built minimal shell with read-eval loop, prompt, bash -c delegation,
      exit handling. Added safety escape hatches: !bash → exec /bin/bash,
      !exit → clean termination. Confirmed ./jeevs.sh execution.
Artifact: Functional login shell. cd fails (process-boundary issue).

[02 · 2025-12-24 · Session 2]
Goal: Fix cd failure.
Work: Added echo greeting "At your service." (Basha's idea).
      Identified cd failure as process-boundary issue — bash -c forks a
      subshell, so cd has no effect on the parent. Installed cd builtin handler.
Artifact: cd handling present but still broken — wrong file being edited
          (~/jeevs.sh not /usr/local/bin/jeevs).

[03 · 2025-12-28 · Session 3]
Goal: Uncover and resolve cd error.
Work: Root cause identified: edits were being made to the development copy,
      not the live login shell at /usr/local/bin/jeevs.
      Established rule: all functional changes must target /usr/local/bin/jeevs.
      Clarified two-path deployment model (dev copy vs. live binary).
Artifact: cd works. Jeevs still leaks raw stderr alongside programmed dialogue.

[04 · 2025-12-31 · Session 4]
Goal: Suppress stderr, implement input routing, stabilize production binary.
Work: Redirected shell execution errors to /dev/null via exec 2>/dev/null.
      Split input into two categories: raw shell commands → bash -c;
      natural language / intent → jeevs_interpret().
      Merged routing into jeevs_1.3. Removed !bash and !exit escape hatches.
      Discovered silent exit on startup — cause unknown at time of logging.
Artifact: Expanded codebase with zero net functionality gain (regression).

[05 · 2026-01-01 · Session 5]
Goal: Stabilize Jeevs as production-grade login shell after dialogic routing merge.
Work: Post-integration debugging. Resolved startup exit regression.
Artifact: Jeevs 1.3.2 — routes errors to /dev/null, responds to select natural
          language commands. Dialogic interpreter still partially broken.
Future: Fix so Jeevs interprets both shell commands and natural language correctly.
```

The Python rewrite (this codebase) is the direct continuation of that work —
solving the fundamental problem that a bash script cannot safely host an LLM
reasoning layer without one of them undermining the other.
