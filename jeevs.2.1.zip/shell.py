"""
shell.py — Jeevs Shell (Display, Confirmation & Execution)
-----------------------------------------------------------
Key changes from MVP:
  - Three-tier confirmation gate: SAFE (none) / STANDARD (y/n) / DANGEROUS (type YES)
  - Plan editing: type 'e' at any confirm prompt to open $EDITOR
  - Token budget warnings shown after each LLM call
  - Sandbox status displayed in banner
  - Built-in :debug command to show raw LLM response
"""

from __future__ import annotations

import os
import sys
import textwrap
from typing import Any

from agent import Agent, AgentError, AgentPlan, ToolCall, TokenBudgetExceeded
from config import (
    DANGER_COLOR,
    DIM_COLOR,
    ERROR_COLOR,
    PLAN_HEADER,
    PROMPT,
    RESET_COLOR,
    SUCCESS_COLOR,
    WARN_COLOR,
)
from editor import open_plan_in_editor
from memory import ActionLogger, SessionMemory
from security import CommandTier, SandboxViolation, get_sandbox_root, init_lists
from tools import ToolError, get_tool, list_tools, runtime_tier


# ── Colour helpers ────────────────────────────────────────────────────────────

def _c(color: str, text: str) -> str:
    return f"{color}{text}{RESET_COLOR}" if sys.stdout.isatty() else text


def _separator(width: int = 54) -> str:
    return _c(DIM_COLOR, "─" * width)


# ── Banner ────────────────────────────────────────────────────────────────────

def _banner() -> str:
    """
    Shell identity box followed by the agent's spoken greeting.

    'At your service.' originated in Session 2 (2025-12-24) of the original
    Jeevs bash prototype — Basha's idea, to give the agent an active voice and
    distinguish it from a passive tool. It appeared on the first line of every
    version: 1.0, 1.2, 1.3, 1.3.2. It is preserved here unchanged.
    """
    sandbox = get_sandbox_root()
    sandbox_line = (
        f"\n  {_c(WARN_COLOR, 'Sandbox:')} {sandbox}"
        if sandbox else ""
    )
    shell_box = (
        f"\n{_c(SUCCESS_COLOR, 'Jeevs')} — Intelligent Shell  v0.2.0"
        f"{sandbox_line}"
    )
    # The greeting — Jeevs speaks first, in its own voice.
    greeting = f"\n{_c(SUCCESS_COLOR, 'At your service.')}"
    hint     = f"\n{_c(DIM_COLOR, 'Type a natural-language instruction, or :help for commands.')}\n"
    return shell_box + greeting + hint


# ── Plan rendering ────────────────────────────────────────────────────────────

_TIER_LABELS = {
    CommandTier.SAFE:      ("", ""),
    CommandTier.STANDARD:  (_c(WARN_COLOR,   " [confirm]"), ""),
    CommandTier.DANGEROUS: (_c(DANGER_COLOR, " [⚠ DANGEROUS — requires YES]"), ""),
}


def _render_plan(plan: AgentPlan, tiers: list[CommandTier]) -> None:
    print(PLAN_HEADER)
    if plan.explanation:
        print(f"  {_c(DIM_COLOR, plan.explanation)}")
    print()
    for i, (step, tier) in enumerate(zip(plan.steps, tiers), 1):
        tool_def = get_tool(step.tool_name)
        label = tool_def.summary(step.args) if tool_def else f"{step.tool_name}({step.args})"
        tier_tag, _ = _TIER_LABELS[tier]
        print(f"  {_c(WARN_COLOR, str(i) + '.')} {label}{tier_tag}")
        if step.reason:
            print(f"     {_c(DIM_COLOR, step.reason)}")
    print()


# ── Tiered confirmation ───────────────────────────────────────────────────────

def _confirm_standard(prompt_text: str) -> str:
    """Prompt y/n/e. Returns 'yes', 'no', or 'edit'."""
    try:
        answer = input(prompt_text).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return "no"
    if answer in ("e", "edit"):
        return "edit"
    return "yes" if answer in ("y", "yes") else "no"


def _confirm_dangerous(command_desc: str) -> bool:
    """Require user to type exactly YES (all caps) to proceed."""
    print(
        _c(DANGER_COLOR,
           "\n  ⚠  DANGEROUS OPERATION — this may be irreversible.\n") +
        f"  {_c(DIM_COLOR, command_desc)}\n"
    )
    try:
        answer = input('  Type YES (all caps) to confirm, or anything else to cancel: ').strip()
    except (EOFError, KeyboardInterrupt):
        return False
    return answer == "YES"


def _needs_dangerous_confirm(tiers: list[CommandTier]) -> bool:
    return any(t == CommandTier.DANGEROUS for t in tiers)


def _needs_any_confirm(tiers: list[CommandTier]) -> bool:
    return any(t != CommandTier.SAFE for t in tiers)


# ── Execution ─────────────────────────────────────────────────────────────────

def _execute_step(step: ToolCall) -> str:
    tool_def = get_tool(step.tool_name)
    if tool_def is None:
        raise ToolError(f"Unknown tool: {step.tool_name!r}")
    kwargs = {k: v for k, v in step.args.items() if v is not None}
    return tool_def.fn(**kwargs)


# ── Built-ins ─────────────────────────────────────────────────────────────────

BUILTINS = {":help", ":h", ":tools", ":history", ":clear",
            ":exit", ":quit", ":q", ":debug", ":budget"}

_last_raw_response: str = ""


def _handle_builtin(
    cmd: str, memory: SessionMemory, logger: ActionLogger, agent: Agent
) -> bool:
    cmd = cmd.strip().lower()
    if cmd not in BUILTINS:
        return False

    if cmd in (":exit", ":quit", ":q"):
        print(_c(DIM_COLOR, "\nGoodbye.\n"))
        logger.log_session_end()
        sys.exit(0)

    elif cmd in (":help", ":h"):
        print(f"""
{_c(WARN_COLOR, 'Built-in commands:')}
  :help    — This message
  :tools   — List available tools and their tiers
  :history — Show session message count
  :budget  — Show token budget usage
  :debug   — Show raw LLM response from last turn
  :clear   — Clear the screen
  :exit    — Exit Jeevs

{_c(WARN_COLOR, 'At a confirmation prompt:')}
  y / yes  — Confirm and execute
  n / no   — Cancel
  e / edit — Open plan in $EDITOR before executing

{_c(WARN_COLOR, 'Confirmation tiers:')}
  (no label)               — Read-only, executes immediately
  {_c(WARN_COLOR, '[confirm]')}                — Mutating, requires y/n
  {_c(DANGER_COLOR, '[⚠ DANGEROUS]')}           — Destructive, requires typing YES

{_c(WARN_COLOR, 'Environment variables:')}
  JEEVS_SANDBOX_ROOT   — Restrict all operations to a directory
  JEEVS_BLOCKLIST      — Colon-separated blocked command prefixes
  JEEVS_ALLOWLIST      — Colon-separated trusted command prefixes
  JEEVS_TOKEN_WARN     — Token count at which to warn (default 40000)
  JEEVS_TOKEN_HARD     — Hard token stop (default 100000)
""")

    elif cmd == ":tools":
        print()
        print(list_tools())

    elif cmd == ":history":
        print(f"\n  Session history: {len(memory)} message(s) in context.\n")

    elif cmd == ":budget":
        total = agent.budget.total
        from config import TOKEN_BUDGET_HARD, TOKEN_BUDGET_WARN
        pct = 100 * total // TOKEN_BUDGET_HARD if TOKEN_BUDGET_HARD else 0
        status = "⚠ approaching limit" if total >= TOKEN_BUDGET_WARN else "OK"
        print(f"\n  Token budget: {total:,} / {TOKEN_BUDGET_HARD:,} used ({pct}%) — {status}\n")

    elif cmd == ":debug":
        if _last_raw_response:
            print(f"\n{_c(DIM_COLOR, '── Raw LLM response ──')}\n{_last_raw_response}\n")
        else:
            print("\n  No LLM response yet this session.\n")

    elif cmd == ":clear":
        os.system("clear" if sys.platform != "win32" else "cls")

    return True


# ── Main loop ─────────────────────────────────────────────────────────────────

class JeevsShell:
    def __init__(self) -> None:
        init_lists()   # Load blocklist / allowlist once at startup
        self.agent  = Agent()
        self.memory = SessionMemory()
        self.logger = ActionLogger()

    def run(self) -> None:
        global _last_raw_response
        self.logger.log_session_start()
        print(_banner())

        while True:
            # ── Input ──────────────────────────────────────────────────────
            try:
                user_input = input(PROMPT).strip()
            except (KeyboardInterrupt, EOFError):
                print()
                try:
                    answer = input("  Exit Jeevs? (y/n) ").strip().lower()
                except (EOFError, KeyboardInterrupt):
                    answer = "y"
                if answer in ("y", "yes"):
                    self.logger.log_session_end()
                    print(_c(DIM_COLOR, "\nGoodbye.\n"))
                    break
                continue

            if not user_input:
                continue

            # ── Built-ins ──────────────────────────────────────────────────
            if user_input.startswith(":"):
                _handle_builtin(user_input, self.memory, self.logger, self.agent)
                continue

            self.logger.log_input(user_input)

            # ── Planning ───────────────────────────────────────────────────
            print(_c(DIM_COLOR, "  Thinking…"))
            try:
                plan = self.agent.plan(user_input, self.memory)
            except TokenBudgetExceeded as e:
                print(_c(ERROR_COLOR, f"\n  {e}\n"))
                continue
            except AgentError as e:
                print(_c(ERROR_COLOR, f"\n  Agent error: {e}\n"))
                self.logger.log_error(str(e))
                continue

            _last_raw_response = plan.raw_response

            # Budget warning after each call
            warn = self.agent.budget_status()
            if warn:
                print(_c(WARN_COLOR, f"  {warn}"))

            # ── Empty plan ─────────────────────────────────────────────────
            if plan.is_empty:
                msg = plan.explanation or "I couldn't generate a plan for that request."
                print(f"\n  {msg}\n")
                self.memory.add_user(user_input)
                self.memory.add_assistant(msg)
                continue

            # ── Classify tiers ─────────────────────────────────────────────
            tiers = [runtime_tier(s.tool_name, s.args) for s in plan.steps]

            # ── Render ─────────────────────────────────────────────────────
            _render_plan(plan, tiers)
            self.logger.log_plan([
                {"tool": s.tool_name, "args": s.args, "tier": t.name}
                for s, t in zip(plan.steps, tiers)
            ])

            # ── Confirmation gate ──────────────────────────────────────────
            if _needs_any_confirm(tiers):
                # Dangerous: require typed YES for the whole plan
                if _needs_dangerous_confirm(tiers):
                    dangerous_steps = [
                        get_tool(s.tool_name).summary(s.args) if get_tool(s.tool_name) else s.tool_name
                        for s, t in zip(plan.steps, tiers)
                        if t == CommandTier.DANGEROUS
                    ]
                    desc = "; ".join(dangerous_steps)
                    confirmed = _confirm_dangerous(desc)
                    if not confirmed:
                        print(_c(DIM_COLOR, "  Cancelled.\n"))
                        self.logger.log_execution("(cancelled)", {}, "", confirmed=False)
                        self.memory.add_user(user_input)
                        self.memory.add_assistant("(user cancelled dangerous plan)")
                        continue

                else:
                    # Standard: y/n/edit
                    answer = _confirm_standard("Execute? (y/n/e to edit) ")

                    if answer == "edit":
                        edited = open_plan_in_editor(plan)
                        if edited is None:
                            # Editor failed or no change; re-prompt
                            answer = _confirm_standard("Execute original plan? (y/n) ")
                        else:
                            plan  = edited
                            tiers = [runtime_tier(s.tool_name, s.args) for s in plan.steps]
                            print()
                            _render_plan(plan, tiers)
                            answer = _confirm_standard("Execute edited plan? (y/n) ")

                    if answer != "yes":
                        print(_c(DIM_COLOR, "  Cancelled.\n"))
                        self.logger.log_execution("(cancelled)", {}, "", confirmed=False)
                        self.memory.add_user(user_input)
                        self.memory.add_assistant("(user cancelled)")
                        continue

            # ── Execute ────────────────────────────────────────────────────
            all_results: list[str] = []

            for i, step in enumerate(plan.steps, 1):
                print(_c(DIM_COLOR, f"  [{i}/{len(plan.steps)}] {step.tool_name}…"))
                try:
                    result = _execute_step(step)
                    all_results.append(result)
                    print(_separator())
                    print(result)
                    print(_separator())
                    self.logger.log_execution(
                        step.tool_name, step.args, result, confirmed=True
                    )
                except (ToolError, SandboxViolation) as e:
                    err = str(e)
                    print(_c(ERROR_COLOR, f"\n  Error: {err}\n"))
                    self.logger.log_error(err)
                    all_results.append(f"ERROR: {err}")
                    if i < len(plan.steps):
                        try:
                            cont = input("  Continue remaining steps? (y/n) ").strip().lower()
                        except (EOFError, KeyboardInterrupt):
                            cont = "n"
                        if cont not in ("y", "yes"):
                            break

            # ── Update memory ──────────────────────────────────────────────
            combined = "\n---\n".join(all_results)
            summary  = (
                f"Plan: {plan.explanation}\n"
                f"Results:\n{textwrap.shorten(combined, width=1000)}"
            )
            self.memory.add_user(user_input)
            self.memory.add_assistant(summary)
            print()
